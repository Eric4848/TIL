function mytest(){
    alert('외부파일에서 실행 됨')
}