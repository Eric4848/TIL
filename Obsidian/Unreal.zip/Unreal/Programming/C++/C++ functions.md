1. 로그를 남기는 함수 - UE_LOG(LogTemp, Log, Text("출력할 문자")) /(이름, 형식, 내용)
2. 변수가 초기화될 때 호출하는 함수 - PostInitProperties()
3. 변수가 수정될 때 호출하는 함수 - PostEditChangeProperty()