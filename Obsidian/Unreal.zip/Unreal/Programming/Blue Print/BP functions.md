1. Get Player Controller
2. Enable Input